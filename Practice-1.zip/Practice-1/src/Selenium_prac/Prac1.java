package Selenium_prac;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Prac1 {
	private static String gender = "Male";
	private static String exp = "5";

	public static void main(String[] args) {
		
		
		System.setProperty("webdriver.chrome.driver", "F:\\Selenium Drivers\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(120,TimeUnit.SECONDS);
		
		driver.get("http://toolsqa.com/automation-practice-form/");
		
		OR or = new OR(driver);
		
		if(or.formHeader.isDisplayed()){
		   System.out.println("Reached Automation Form page");
		}else{
		   System.out.println("Failed to reach Automation Form page");
		}
		
		if(or.firstName.isDisplayed()) or.firstName.sendKeys("Nishant");
		
		if(or.lastName.isDisplayed()) or.lastName.sendKeys("Nair");

		
		if(or.parentGender.isDisplayed()) {
		   or.parentGender.findElement(By.xpath("input[@value='"+gender+"']")).click();
		}

		if(or.parentExp.isDisplayed()) {
		   or.parentExp.findElement(By.xpath("input[@value='"+exp+"']")).click();
		}
		
		if(or.selectContinents.isDisplayed()){
		   Select sel = new Select(or.selectContinents);
		   sel.selectByVisibleText("Australia");
		}
	}
	
}
