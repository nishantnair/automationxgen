package Selenium_prac;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class prac_1 {

	public static void main(String[] args) {
	/*System.setProperty("webdriver.gecko.driver","F:\\Selenium Drivers\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.navigate().to("http://www.DemoQA.com");*/
		
		//Setting the path of Chrome WebDriver 
		String exePath = "F:\\Selenium Drivers\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver driver1 = new ChromeDriver();
		driver1.get("http://toolsqa.wpengine.com/automation-practice-form/");
		
		
	}

}
