package Selenium_prac;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Prac3 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "F:\\Selenium Drivers\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(120,TimeUnit.SECONDS);
		
		driver.get("http://toolsqa.com/automation-practice-table/");
		
		OR or = new OR(driver);
		
		
		List<WebElement> thead = or.tableStructure.findElements(By.xpath("thead//th"));
		List<WebElement> tbody = or.tableStructure.findElements(By.xpath("tbody//tr"));
		
		for(WebElement th : thead){
		    System.out.print(th.getText()+" | ");
		}
		
		System.out.println();
		
		for(WebElement tr : tbody){
			List<WebElement> td = tr.findElements(By.xpath("td"));
			for(WebElement col : td){
				System.out.print(col.getText()+" | ");
			}
			System.out.println();
		}
		
		for(int i=0;i<=tbody.size()-1;i++){
			List<WebElement> td = tbody.get(i).findElements(By.xpath("td"));
			for(int j=0;j<=td.size()-1;j++){
				System.out.print(td.get(j).getText()+ " | ");
				if(j == 5) td.get(j).findElement(By.xpath("a")).click();
			}
			System.out.println();
		}
	}

}
