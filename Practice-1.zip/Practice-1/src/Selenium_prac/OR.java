package Selenium_prac;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OR {
	
	@FindBy(xpath=".//h1[text()='Practice Automation Form']")
	public WebElement formHeader;
	//Inputbox - First Name
	@FindBy(xpath=".//input[@name='firstname']")
	public WebElement firstName;
	//Inputbox - Last Name
	@FindBy(xpath=".//input[@name='lastname']")
	public WebElement lastName;
	//Radio Button -Sex
	@FindBy(xpath=".//input[contains(@id,'sex')]/..")
	public WebElement parentGender;
	
	//Radio Button - experience 
	@FindBy(xpath=".//input[contains(@id,'exp')]/..")
	public WebElement parentExp;
	
	//Dropdown- Continents
	@FindBy(xpath=".//select[@id='continents']")
	public WebElement selectContinents;
	
	@FindBy(xpath=".//table[@class='tsc_table_s13']")
	public WebElement tableStructure;
	
	@FindBy(xpath=".//input[@name='fromPlaceName']")
	public WebElement txtFromPlace;
	
	@FindBy(xpath=".//input[@name='searchBtn']")
	public WebElement btnSearch;
	
	@FindBy(xpath=".//input[@name='photo']")
	public WebElement selectfile;
	
	public OR (WebDriver driver){
		PageFactory.initElements(driver, this); // initializing elements
	}
	
	
	
	
}
