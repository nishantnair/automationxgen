package Selenium_prac;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;

public class Prac4 {
// Handling Alerts
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "F:\\Selenium Drivers\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(120,TimeUnit.SECONDS);
		
		driver.get("http://www.ksrtc.in");
		
		OR or = new OR(driver);
		
		if(or.txtFromPlace.isDisplayed()) or.txtFromPlace.sendKeys("Bangalore");
		
		if(or.btnSearch.isDisplayed()) or.btnSearch.click();
		
		Alert alert = driver.switchTo().alert();
		
		if(alert.getText().equals("Please select end place.")) alert.accept();
		
		
		
		
		

	}

}