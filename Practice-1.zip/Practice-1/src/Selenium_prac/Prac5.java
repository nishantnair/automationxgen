package Selenium_prac;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Match;
import org.sikuli.script.Screen;
public class Prac5 {
	public static void main(String[] args) throws FindFailed {
	System.setProperty("webdriver.chrome.driver", "F:\\Selenium Drivers\\chromedriver_win32\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();
	
	driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
	driver.manage().window().maximize();
	driver.manage().timeouts().pageLoadTimeout(120,TimeUnit.SECONDS);
	
	driver.get("http://toolsqa.com/automation-practice-form/");
	
	OR or = new OR(driver);
	if(or.selectfile.isDisplayed()) or.selectfile.click();
	Screen s=new Screen();
	Match filename = s.find("F:\\Sikuli Images\\FileName.PNG");
	filename.click();
	filename.type("F:\\Sikuli Images\\FileName.PNG",0);
	Match btnOpen = s.find("F:\\Sikuli Images\\Open.PNG");
	btnOpen.click();
}
}
