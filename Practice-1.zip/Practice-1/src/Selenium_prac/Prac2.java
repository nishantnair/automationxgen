package Selenium_prac;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Prac2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "F:\\Selenium Drivers\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(120,TimeUnit.SECONDS);
		
		driver.get("https://www.google.co.in/");
		
		WebElement ele = driver.findElement(By.xpath(".//div[@id='_eEe']/a[1]"));
		
		Actions act = new Actions(driver);
		
		act.sendKeys(Keys.CONTROL).click(ele).build().perform();
		
		

	}

}
